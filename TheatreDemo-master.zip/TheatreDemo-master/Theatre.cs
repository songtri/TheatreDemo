﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheatreDemo
{
	class Theatre
	{
		private List<Show> shows = new List<Show>();
		public string Name { get; }

		public Theatre(string name)
		{
		}

		public void AddShow(Show show)
		{
		}

		public void PrintShows()
		{
		}

		public void PrintShows(Genre genre)
		{
		}

		public void PrintShows(Day day)
		{
		}

		public void PrintShows(Time time)
		{
		}

		public void PrintShows(string actor)
		{
		}

		public void PrintShows(Day day, Time time)
		{
		}
	}
}
